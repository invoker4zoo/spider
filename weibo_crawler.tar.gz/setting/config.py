# coding = utf-8

# cookies saved path
COOKIES_SAVE_PATH = 'setting/cookies.pkl'

# key accounts/value password
accounts = {
    '412214410@qq.com': '4vYzvwdi',
    '17031043041': 'rs576833',
    '17031049811': 'rs576833',
    '17067466403': 'rs576833',
    '15174973696': 'rs576833',
    '17152695951': 'rs576833',
    '17031048208': 'rs576833',
    '17031047261': 'rs576833',
    '17031045183': 'rs576833',
    '17031042005': 'rs576833',
    '17031042172': 'rs576833',
}

MONGO_IP = '192.168.45.140'
MONGO_PORT = 27017

DEFAULT_ID = 1669879400
SEEKING_ID = [
    2846622504,
    512013023,
    'cqnews',
    'prettycq',
    'cqshenghuozixun',
    'cqqnb',
    'cqhhc',
    'cqtravel',
    'baoliao110',
    312280008,
    'cqga110',
    'cqmmgogo',
    'cqwbhcg',
    2413774550,
    640845685,
    6068931035,
    'tianyazaixian',
    'cqszfxwb',
    'hlwygcq',
    'cqnwb',
    'cz023',
    'woaichongqing',
    'cqwb',
    'cqsb',
    'cqtime',
    'comcctv',
    3683828370,
    'jrchongqing',
    'cqcb',
    'cqgov',
    '91wyq',
    'zhengfu',
    'chinanewsv',
    'nddaily',
    'cqrb',
]